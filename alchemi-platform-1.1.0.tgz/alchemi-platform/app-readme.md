# AlchemiStudio Platform

The **AlchemiStudio AI platform** (web, AI, compute, workers, guardrails, and auth), packaged for SUSE Rancher / AI Factory.

## What you get
- A **full, working install** on your RKE2 / Rancher-managed cluster from one guided form.
- **Images pull automatically** from AlchemiStudio's registry — no credentials to set up.
- Runs in **fixed-seats mode** — no license key required to install and evaluate.
- Bundled by default: **PostgreSQL, Redis, object storage, Keycloak** — nothing external to provision.

## Before you install
Your cluster already exists — the trial only asks for **application** settings:
- **Base domain** (e.g. `alchemi.acme.com`) and TLS mode (`selfsigned` is fine for trials)
- **Admin email** — this becomes your first login
- Optional: sizing tier, SMTP, and LLM provider keys

You do **not** need to configure a registry, credentials, VNet, or nodes.

## ⏱️ Before you click Install — give it 30 minutes
The first install pulls **several GB of images**. Raise the install timeout so it doesn't stop early:
tick **"Customize Helm options"** → set **Timeout = `1800`** (30 min), *or* uncheck **Wait**.
The default 10-minute timeout can be too short and leaves the release stuck ("another operation in progress").

## AI guardrails are OFF by default
The **AI-safety tier** (PII, secret-detection, jailbreak, toxicity, topical, content-filter) is **disabled by default** to keep the first install fast and light. Turn on **"Enable AI guardrails"** in the form when you're ready — ideally as a **later upgrade** with a 30-min timeout (it adds 6 services and pulls several GB of model images).

## Prefer the command line?
```sh
helm repo add alchemi https://zentiencelabs.github.io/alchemi-public-helm-charts
helm repo update
helm install alchemi-platform alchemi/alchemi-platform --version 1.1.0 \
  -n alchemi --create-namespace \
  --set global.domain=alchemi.acme.com \
  --set admin.email=you@acme.com \
  --wait --timeout 30m
```
(no registry creds needed — the trial pull-token is baked into the chart.)

## Moving to production
When you're ready to run in production — your **own registry**, a **license**, multi-tenant scale, and support — reach out and we'll set you up (it's an in-place upgrade of this same install; your data is preserved):

**📧 support@alchemistudio.ai**

Production adds: mirroring images into your own registry, a licensed plan (managed centrally, no redeploy), and air-gapped options.

---
*Trial usage is subject to fixed-seat limits. The trial registers with AlchemiStudio so we can support your evaluation.*
