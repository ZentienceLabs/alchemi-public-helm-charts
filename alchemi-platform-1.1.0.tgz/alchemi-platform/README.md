# alchemi-platform (umbrella chart)

The **single deliverable** for SUSE: one chart that installs Alchemi and powers **both** delivery models
(see [`../../10-domain-and-routing.md`](../../10-domain-and-routing.md) §3b):

- **Rancher App** — install from Rancher → Apps; `questions.yaml` renders a **guided form** (domain, cert,
  license, dependency toggles). This is the form-driven path.
- **AI Factory Blueprint** — reference this chart as a **single component** (see
  [`../../fleet/blueprint/alchemi-platform.blueprint.yaml`](../../fleet/blueprint/alchemi-platform.blueprint.yaml));
  the card shows in the AI Factory catalog and installs this same chart. No form there → domain via values.

## What it does

- Wraps the per-service Alchemi charts (from the `alchemi-charts` OCI repo) as **dependencies**, each gated by
  an `<svc>.enabled` toggle.
- Takes **one input, `global.domain`**, and fans it out (via `_helpers.tpl`) to:
  - **APISIX routes** (`templates/apisix-routes-job.yaml`) — the subdomain→service map,
  - the **`alchemi-endpoints` ConfigMap** — derived hosts/URLs + the Keycloak **redirect URI**,
  - the **TLS SNIs** bound to the wildcard cert.
- Exposes the `*_MODE=external` toggles so one chart fits customers who already run PG/Redis/observability.

## Install (Rancher App / Helm)

```bash
# pin the subchart versions first (they're REPLACE in Chart.yaml):
#   helm show chart oci://alchemiacr.azurecr.io/helm/<name> | grep '^version'
helm dependency update .
helm upgrade --install alchemi . -n alchemi --create-namespace \
  --set global.domain=acme.com \
  --set license.jwt=<JWT> \
  --set tls.secretName=apisix-ssl-secret
```

## From form to install — what each input drives

Modeled on the Azure Marketplace offer (`azure-marketplace/offer/createUiDefinition.json`) + its bootstrap,
so the form collects everything an install needs and wires it through:

| Form input | Flows to |
|---|---|
| `global.domain` | APISIX routes, TLS SNIs, Keycloak hostname + redirect URI, **account domain** (seed) |
| `admin.email` | Keycloak admin, **first-user seed**, alerts, `alchemi-endpoints` |
| `admin.name` / `admin.orgName` | first-user name / account name — **derived like Azure** if blank (email local-part / domain first label) |
| `license.jwt` | `alchemi-license` secret |
| `tier`, `smtp.*`, `*_MODE=external` | sizing, mail, dependency wiring |
| — (generated, never asked) | `alchemi-secrets`: encryption key, JWT/NextAuth, Keycloak client secrets, PG/Redis passwords — `openssl rand` equivalent, **persisted across upgrades** (`lookup` + `resource-policy: keep`) so keys don't rotate |

**DB init (migrate ≠ seed):** the `-db-init` post-install Job runs the migrator (schema) then the ported
first-user + account seed (`seed-configmap.yaml`, from `azure-marketplace/.../seed/{01-users,02-account}.sql`),
using `ADMIN_EMAIL`/`ADMIN_NAME`/`ACCOUNT_NAME`/`CUSTOMER_DOMAIN` from the form. Idempotent (`ON CONFLICT`).

> Verify the migrator invocation for your image (`seed-job.yaml` step 1) — set `seed.migratorImage` / adjust
> the command if your migrator isn't run by its default entrypoint.

## The one integration point (app charts)

Helm can't template `values.yaml`, so the umbrella computes the derived hosts into the **`alchemi-endpoints`
ConfigMap** and the app charts should **`envFrom`** it:

```yaml
envFrom:
  - configMapRef: { name: alchemi-endpoints }
```

This is a **proposed app-chart change** (not made here — app charts live outside this repo). Until it lands,
set the same host values via each subchart's `config.data` in a values override. The umbrella-owned pieces
(APISIX routes + TLS) already use the derived hosts, so **routing/TLS work regardless**.

## Form parity with the Azure Marketplace offer

`questions.yaml` was cross-checked against `azure-marketplace/offer/createUiDefinition.json` (the proven
input spec). Mapping:

| Azure form field | SUSE `questions.yaml` |
|---|---|
| `customerDomain` | `global.domain` |
| `appSubdomain`/`authSubdomain`/`opsSubdomain`/`zenithSubdomain` | `global.subdomains.*` (ops, matching Azure + SUSE) |
| `adminEmail` | `admin.email` (**required** — seed↔login) |
| `tier` (basic/standard/premium) | `tier` |
| `licenseJwt` | `license.jwt` |
| `emailMode`/`smtp*` | `smtp.mode` + `smtp.*` (no ACS on SUSE → `none`\|`smtp`) |
| `tlsPfx`(+password) | `tls.secretName`/`tls.mode` (k8s PEM secret, not a .pfx upload) |
| `brandLogo` | `branding.logoBase64` |

**Azure-only fields intentionally absent** (the customer already owns the platform — our scope split):
`kubernetesVersion`, `jumpbox*`, `redisKind`, `hardenClusterAuth`, `privateRegistryAndStorage`,
`credentialAdminObjectId`. On SUSE these are the customer's RKE2/Rancher concern, not ours.

## Data tier (folded in)

Bundled **pgvector PostgreSQL** (`data-postgres.yaml`) and **Redis** (`data-redis.yaml`) are now chart
templates, gated by `postgres.mode`/`redis.mode` (`bundled`|`external`) — so one form install stands up the
data stores, and a customer with their own PG/Redis flips to `external`. The `-db-init` Job creates the
`vector`/`uuid-ossp`/`pgcrypto` extensions + the extra DBs (keycloak, aistore) **before** migrate — the
migrator fails on the first migration without the `vector` type. Passwords come from `alchemi-secrets`.

## Gateway (folded in)

Bundled **APISIX + etcd** (`gateway-apisix.yaml`, `gateway-etcd.yaml`), gated by `gateway.mode`
(`bundled`|`external`). The APISIX config is ported from the **proven on-prem manifests** — so it already
carries the **256k proxy buffers** (Keycloak OIDC `Set-Cookie` → 502 without them), **X-Forwarded-Proto=https**
(KC scheme detection), 100m body, and 1200s timeouts. Exposed via `gateway.serviceType` (`auto`=LoadBalancer,
rides the cluster's LB). The routes Job (also `bundled`-gated) configures the subdomain→service map on it.
`gateway.mode=external` → no APISIX, and the customer points their own gateway at the same routes.

## Data tier — complete

**pgvector PostgreSQL, Redis, APISIX(+etcd), and OpenObserve** are all folded in as templates, each with a
`bundled`/`external` toggle. One `helm install` (the form) now stands up the whole platform — data tier +
gateway + apps. OpenObserve root password is generated complexity-safe (OpenObserve rejects weak passwords);
`observability.persist=true` swaps emptyDir → PVC.

## Publish (make it installable from the form)

Dependency versions are **pinned** (web/ai/worker/zenith/keycloak/guardrails `1.0.0`, compute-api `0.1.0`).
To publish so it appears in Rancher → Apps:

```bash
../../helm-charts/push-charts.sh          # 1. per-service subcharts -> oci://<registry>/helm
../publish.sh                              # 2. umbrella: dep update + package + push
```

`publish.sh` supports ACR (`az acr login`) or a Harbor hub (`REGISTRY=harbor… REGISTRY_USER/PASSWORD`).

## Still TODO before GA

1. **App runtime config (the big one).** The chart wires namespaces, service DNS, the data tier, secrets, and
   the seed — but the app subcharts still receive **no `config.data`**, so pods come up without `DB_HOST` /
   `REDIS_HOST` / `KC_HOSTNAME` / the app secrets. Two halves:
   - **Static infra config** (service DNS) → set per-subchart `config.data` in values: `DB_HOST=alchemi-pgvector.alchemi-data.svc`,
     `REDIS_HOST=alchemi-redis.alchemi-data.svc`, `OPENOBSERVE_URL=…observability.svc:5080`, compute-api's asyncpg `DATABASE_URL` (bare, no `?sslmode=`).
   - **Domain-derived + secret config** → app charts **`envFrom: alchemi-endpoints`** (hosts/redirect URI) +
     the app secrets from `alchemi-secrets` (the one proposed app-repo change).
2. Run the publish (above) against the real registry, add the ClusterRepo in Rancher, Install from Apps.
3. Sanity-check the migrator against the published `migrator:platform-<tag>` image on the live cluster.
4. Object store: fold in a real store (Blob-vs-S3 decision) — `objectStore.mode=bundled` is a TODO stub.

**Resolved (bug hunt):** k8s `$(PGPASSWORD)` expansion, external-mode DB creds, Keycloak port (8080),
subchart service DNS (fullnameOverride + namespace), DB names (`alchemiapp_db`/`compute_db`), the real
`db_tool.py` migrate command.
